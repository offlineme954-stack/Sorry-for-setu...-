GITHUB PAGES — QUICK SETUP

1. GitHub-এ একটি Public repository তৈরি করুন।
2. এই ZIP থেকে index.html বের করে repository-র root-এ upload করুন।
3. Settings → Pages → Build and deployment → Source: Deploy from a branch
4. Branch: main এবং Folder: / (root) নির্বাচন করে Save করুন।
5. কিছু সময় অপেক্ষা করুন। তারপর Visit site চাপুন।

গুরুত্বপূর্ণ:
- এটি সম্পূর্ণ static website।
- কোনো Admin Panel, password, Gmail message system বা database নেই।
- ভিউ কাউন্টারটি শুধু একই browser/device-এ localStorage ব্যবহার করে। এটি সব visitor-এর global count নয়।
- Messenger button আপনার দেওয়া Facebook/Messenger profile-এ যায়।
